# B08 Report — annotated outline (Phase 1)

**Status:** scaffold complete, prose not written. Every `.tex` section file carries its page
budget, its content bullets, `% EVIDENCE:` comments naming the exact `file:line` or dated
prompt to cite, and `\todoprose{}` markers where prose goes.

**Companion documents:** [`STYLE.md`](STYLE.md) — the writing profile governing Phase 2 ·
[`figures/screenshots/README.md`](figures/screenshots/README.md) — capture checklist.

---

## The argument

**Thesis.** The AI was a fast, fluent generator that was frequently wrong in ways only domain
reasoning and empirical measurement could catch. The engineering contribution is the
verification loop built around it.

**The strongest claim available, and it is fully evidenced:** the fracture model was
*redesigned by the author* and *implemented by the AI* — not the reverse. §8.4 documents it
beat by beat with verbatim quotes.

**Tone.** Engineering report: first person, past tense, evidence-led. Every non-obvious claim
cites an artifact — a measured number, a `file:line`, or a dated prompt. Do not
anthropomorphise the model.

**What to resist.** Spending pages on §2 (engine fundamentals) — the least original material.
The marks live in §5, §6 and §8. **Candour is load-bearing in §8**: "the AI wrote it and it
worked" is worthless; a loop that *caught* an inverted sign, an inverted semantic, a silently
non-conservative energy model and a 3.6 ms GPU stall is the deliverable.

---

## Page budget (~18.75 pp body + appendices)

| § | Title | pp | File |
|---|-------|----|------|
| — | Title, abstract, TOC | 1.0 | `main.tex` |
| 1 | Introduction & compliance | 1.5 | `sections/01-introduction.tex` |
| 2 | How a game engine works | 1.25 | `sections/02-engine-fundamentals.tex` |
| 3 | Architecture | 2.5 | `sections/03-architecture.tex` |
| 4 | Physics and collision | 2.0 | `sections/04-physics.tex` |
| **5** | **Destruction: the fracture graph** | **3.0** | `sections/05-destruction.tex` |
| **6** | **The game** | **2.5** | `sections/06-game.tex` |
| 7 | Testing, performance, limitations | 2.0 | `sections/07-testing-performance.tex` |
| **8** | **AI usage & verification** | **4.0** | `sections/08-ai-usage.tex` |
| 9 | Conclusion & future work | 0.5 | `sections/09-conclusion.tex` |
| A–E | Appendices | — | `sections/appendix-*.tex` |

> **This exceeds the original ~15 pp target by ~4 pp**, because §6 was expanded and the C#
> features and model-redesign material were added. If 15 is a hard cap, compress in this
> order: (1) §2 → 1 pp, folding the PAL paragraph into §3; (2) §4 formulas into a table with
> minimal prose; (3) move §6.2–6.6 per-system detail into an appendix, leaving a 1 pp
> overview. **Never cut §5, §6 or §8.**

---

## Section notes

### §1 Introduction
Stats, then the **compliance table** mapping each brief clause to a `file:line`. The table is
what pre-empts a strict reading of "C# WinForms". Close on the negative check: the absence of
any timer was *verified by search*, not asserted by design intent.

### §2 Engine fundamentals — compress
Only one part earns its place: **why a WinForms timer cannot express a fixed timestep** (no
frame budget, no catch-up semantics, no control over update/draw ordering). That justifies a
brief requirement rather than restating a textbook.

### §3 Architecture
ECS, deferred destruction, layering, PAL with capability detection, and **§3.4 C# features +
a one-frame composition walkthrough** — the section answering "how do the pieces connect",
which no single file shows.

> **Factual correction carried in here:** there is **no state stack**. Transitions are a flat
> pointer swap; pause is a `_paused` bool inside `PlayingState`; wave transitions construct a
> *new* `PlayingState` and tear down the old `World`. Stated as a consequence and carried into
> §7's limitations.

### §4 Physics
Formulas: dissipated energy `E = k_E·½·m_eff·v_n²·(1−e²)`, sequential impulses with the
30 px/s restitution threshold, parallel-axis inertia. Then **§4.6, the rejected adaptive grid**
— a deferred optimisation *with numbers* (collision profiles at 0.44 ms; the real problem is
bimodal size distribution; only a quadtree would help; not worth the risk against zero
measured cost). A rejected optimisation is better evidence of judgement than an accepted one.

### §5 Destruction — centrepiece
Representation → traversal → fragmentation → time.

Key beats: the **dual-graph framing** (cells = nodes, bonds = edges); the traversal is a
**best-first wavefront**, structurally a maximising Dijkstra, with `Processed[]` as the
settled set; the **energy channel decomposition** and its conservation invariant; the
**recovery rule** (a bond consumes only what it needs, the excess continues forward) — the
mechanism that makes the model conservative rather than merely plausible; **union-find**
components, with the payoff that *thin necks are graph bridges so they split automatically,
with no geometric crack-path search*; and per-front multi-frame pacing with fusing fronts.

### §6 The game — expanded
Framed as the engine's acceptance test but given real space: it is most of the work.
Standouts worth the room:
- **Waves:** *cell budget* is the difficulty currency, with a dual trigger so camping still
  gets pressure. Validated by offline simulation of waves 1–20 before being trusted.
- **Piercing round:** a **sensor with no solver response** plus explicit terminal ballistics —
  the clearest example of stepping outside the generic physics path, and why.
- **Alien AI:** clamped-turn-rate bearing tracking (a *fix*, not a choice) and capability
  gating on surviving cell roles — shooting an engine off is modelled, not scripted.
- **Vortex:** lead with the design problem (a 10× map is empty; camping was viable and dull),
  not the implementation.
- **Camera:** trauma-*squared* shake falloff.

### §7 Testing, performance, limitations — required by the brief
Open by admitting there is no automated test suite; it costs nothing and buys credibility.
The performance narrative is the strongest technical story: **draw-call counters missed the
warp entirely** (few calls, each enormous); `Present`-timing plus A/B toggles found it;
`Draw.VortexWarp` at **3.632 ms against ~1.5 ms for every simulation system combined**.
Then the bug table, then limitations stated plainly — including that
**`ForEachParallel` is defined and called by nothing.**

### §8 AI usage — co-centrepiece
- **8.1 Research phase (lost, reconstructed).** The transcript was destroyed by a 30-day
  retention default; six documents survive. The narrowing funnel is visible in the artifacts.
  **The payoff:** the May grid-vs-quadtree document named the exact condition under which a
  quadtree wins (>~5× size variation); July's profiling found that condition (bimodal); the
  code has not yet crossed it. Research that predicted its own expiry.
- **8.2 Workflow.** Spec → phase → playtest gate → next phase.
- **8.3 Direction changes.** Polygon-cutting → cell/bond graph; GDI+ → shared Skia.
- **8.4 The model redesign.** *The best evidence in the report.* Five beats, quoted.
- **8.5 Failure taxonomy.** Grouped by *kind*, because the kinds are the finding.
- **8.6 The verification loop.** Nine techniques, each with an artifact.

---

## Build

```bash
cd report && ./build.sh          # latexmk -pdf main.tex
```

**Status: builds clean** — 25 pages, 0 errors, 0 undefined references, 0 overfull boxes,
all 9 TikZ figures rendering.

Set `\draftnotesfalse` in `preamble.tex` to hide margin budgets and TODO markers for the
final build. Remove `\nocite{*}` from `main.tex` once real `\cite` commands exist.

### Gotchas that already cost a build — do not repeat

1. **Never write a real control sequence inside `\todoprose{}`.** The argument is *typeset*,
   not printed. `\lstinputlisting` inside a note was executed and swallowed the next word as
   a filename. Use `\mac{lstinputlisting}` to name a macro as text.
2. **`\todoprose` uses `{\bfseries …}`, not `\textbf{…}`**, because `\textbf` is a short
   text-font command and cannot span a paragraph break — and these notes are routinely
   multi-paragraph.
3. **Do not name a TikZ style `cap`** — it collides with the built-in `/tikz/cap` (line cap).
   The figures use `capt`. Other risky names: `join`, `pos`, `text`, `name`, `label`.
4. **Screenshot slots** use `\screenshotslot{path}`, which draws a placeholder box at the
   right size. Replace each with `\includegraphics` once the PNG exists — do not put
   `\includegraphics` in a TODO note (see 1).

### If a build breaks
`latexmk` caches a failed run and then reports "Nothing to do". Always
`latexmk -C` before re-running, and read `main.log` (`grep -n "^!" main.log`) rather than the
terminal tail — the real error is usually many lines above the summary.

---

## Verification checklist (before submitting)

1. `./build.sh` compiles; warnings limited to missing screenshots.
2. Body page count 17–19 (`pdfinfo main.pdf`), appendices excluded.
3. Every `\lstinputlisting` line range resolves and matches current source.
4. All `\ref`/`\cite` resolve; no `??` in output.
5. Re-verify each quantitative claim against its artifact: `profile.log` (timings),
   `wc -l` (LoC), the export (prompt counts).
6. **Re-run the no-timers grep at write time** — it is a load-bearing compliance claim:
   ```bash
   grep -rE "Windows.Forms.Timer|new Timer\(|System.Timers" --include=*.cs src apps tools
   ```
7. Every §8 quotation checked verbatim against `conversation-export/`, with its date.
8. Spot-check that each `refs.bib` URL still resolves.

---

## Open questions for Phase 2

1. **Page cap:** accept ~18.75 pp, or compress to 15 using the levers above?
2. **Screenshots:** capture before drafting §5–§7, so figures and prose are written together?
3. **Language register:** confirm British `-ise` throughout (matches both the corpus and the
   codebase comments).
