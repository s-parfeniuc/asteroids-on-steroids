# Writing-style profile

**Purpose.** This is the governing reference for writing the report's prose in Phase 2.
It exists to separate three things:

1. the **voice** worth carrying into formal prose,
2. the **chat artefacts** to drop, and
3. the **recurring error set** to systematically avoid — because writing in someone's voice
   without knowing their error patterns means reproducing them.

**The report must not mimic the chat register.** The prompts are a source for *idiolect*,
not a template for *documentation*.

**Corpus.** 253 substantive prompts, ~18,400 words, 31 May – 22 July 2026, from
`conversation-export/`. Excludes tool output, session-continuation summaries, and
messages under 60 characters.

**On other reference material.** The files in `docs/` and `info/` are **AI-generated, not
author-written**. They are *not* a sample of the author's writing and must not be used to
model voice. They are useful only as a *register* reference — the technical-documentation
pitch they hit is close to what the report needs. Where the two conflict, this profile wins.

---

## A. Recurring sentence structures

Eight templates account for most of the corpus. This is the transferable part.

**1. Observation → hypothesis → request for judgement.** The dominant unit.

> "I noticed that with more directionality the same impact loses more energy and ends up
> destroying less bonds. Does it make sense to propagate the same quantity of energy but
> bias it more toward the edges with similar direction to the impact trajectory?"

*Report form:* state the measurement, offer the mechanism, then evaluate it. This is already
the natural shape of §7 and §8.

**2. Evaluative preamble + numbered defect list** (28 prompts, 11%).

> "Very good, some issues I found while playtesting: 1… 2… 3…"

A positive clause, then enumerated specifics. **Numbered, never bulleted** — the corpus
contains essentially zero bullet lists.

**3. Acceptance + pivot.**

> "Now it works as I wanted. Let's move on to the last pre-game phase."

Short declarative closure, then forward motion. Good for section transitions.

**4. Deferred-implementation guard** (10×).

> "Let's plan this carefully before implementing." / "Do not code yet." / "No coding for now."

Evidence of process discipline. **Quote these in §8.2 rather than imitating them** — they are
chat instructions, not report prose.

**5. Solicited critique with an open slot.**

> "give a honest opinion on the whole thing: does it make sense to put effort into this
> feature, what would the cost be in terms of project structure/complexity, future
> extendability and whatever you feel like deserves my attention."

The trailing "and whatever else matters" slot recurs.

**6. Self-diagnosis stated as a claim, not a question.**

> "The problem must be that the normal uses the whole compound shape's centroid instead of
> the specific cell that collided."

Confident root-cause assertion. **This is the voice §7 should be written in.**

**7. Contrastive persistence report.** `still` appears **54×** — the signature of iterative
debugging.

> "The recoil happening at impact works fine. Entities still get stuck inside each other…"

Note the non-native mid-clause `however` ("there is a problem however:"); in the report it
needs commas or repositioning.

**8. Purpose-clause chaining** (`so that / so it / so they`, **36×**). Requirements are
habitually expressed as *intent*, not mechanism:

> "cells need to shrink … so they don't perfectly overlap the hole that's created and don't
> stress the collision system as much."

**Keep this** — it is exactly how design rationale should read.

---

## B. Frequency signature (per 253 prompts)

| Marker | Count | What it indicates |
|---|---|---|
| `should` | **164** | The dominant modal. The register is *specification*, not narration. |
| `let's` | 65 | Hortative, collaborative-decisive |
| `still` | 54 | Persistence reporting (iterative debugging) |
| **parenthetical asides** | **129** | ≈0.5 per prompt — a genuine tic |
| `feel` / `feels` / `feeling` | 36 | The primary acceptance criterion is *felt behaviour* |
| `so that` / `so it` | 36 | Intent-first requirements |
| `Also` | 31 | Stacks unrelated issues into one message |
| `maybe` | 27 | Mid-sentence hedge |
| `I think` | 22 | Hedged assertion |
| `actually` | 21 | Correction//pivot marker |
| `what do you think` | 21 | Actively solicits pushback |
| `I noticed` | 13 | Empirical observation opener |
| `honest` | 10 | Explicitly requests candour |
| no-code guard | 10 | Process discipline |

**64 of 253 prompts (25%) end in a question.** Numbered lists in 11%; bullet lists ~0%;
backticks almost never.

**Coinage worth keeping:** **`overtuned`** (4×) — used consistently and precisely for
"parameter set too aggressively". It is good technical shorthand and belongs in §7.

**Typical parenthetical:** *"(doesn't happen often, sometimes with piercing rounds or with
asteroids spawning on top of alien/asteroid cells)"* — qualifies scope of a claim. Keep the
habit, ration it to roughly one per paragraph.

---

## C. Error set — what I must NOT reproduce

The profile is consistent across all three months and does not decay, so it is **systematic
(L1 interference, Romance-language pattern), not careless**. Catalogued so Phase 2 avoids it.

| Type | Observed | Correct form |
|---|---|---|
| Preposition calque | "independently **on** the impact force" (2×) | independently **of** / regardless of |
| `there's` + plural | "there's concave shapes"; "Here's some general changes" (7×) | there **are** / here **are** |
| Subject–verb agreement | "its cells **is** a subset"; "the constant **are**"; "if an object**s** is" | match number |
| `less` + countable | "destroying **less** bonds" | **fewer** bonds |
| Embedded-question inversion | "I was wondering **what's** the directionality" | what the directionality **is** |
| Dropped article | "Can you do ∅ deep check"; "does ∅ restitution direction use" | **a** deep check |
| Dropped subject pronoun | "How would ∅ organize these"; "∅ Think we can start" | how would **you** |
| Dropped object | "I'm going to tell ∅ what needs to be done" | tell **you** |
| Noun calque | "Make clarity on what parameters"; "personalizable" | **clarify which**; **customisable** |
| Missing partitive | "It would make a lot ∅ sense" | a lot **of** sense |
| `a` / `an` | "give **a** honest opinion" | **an** honest |
| Duplication slips | "stayed stayed"; "vaporise completely … completely" | — |
| Recurrent misspellings | dwarfes, conviced, completeley, entilrely, independtly, responsibilites, Wille, transfroms, conviced | — |

**Spelling convention: British `-ise`** (vaporise, normalise, pulverise, optimise), used
consistently and matching the codebase comments. Keep it.

> **Note for quotations:** none of the above applies inside quoted exhibits. Quote prompts
> **exactly**, errors included. Silently correcting a quotation destroys its value as evidence.

---

## D. Vibe — how the author comes across

**A hands-on systems empiricist who owns the design and delegates the mechanism.**

- **Judges by felt behaviour, then verifies numerically.** `feel` 36×, but every important
  claim gets an instrument behind it — printed energies, `profile.log`, offline simulation.
- **Understanding is a precondition, not a bonus.** *"I want to understand this model more
  before committing to it"*; *"correct me where I'm wrong and be precise."* Recurs May→July.
- **Firmly in charge, without posturing.** Gates implementation, sets order, defers features —
  yet concedes quickly and without ego (*"I agree with your proposal"*) and actively asks for
  pushback (`honest` 10×, `what do you think` 21×).
- **Low tolerance for unexplained complexity.** *"a hell to understand and to tune"* — and it
  triggered a full redesign. Comprehensibility is treated as a correctness property.
- **Informal warmth inside precise technical vocabulary** — *"would be cool"*, *"shtick"*,
  *"juice"*, *"strat"* sit beside *reduced mass*, *connected components*, *directionality*.
  **Translate this trait rather than copying it:** keep the unpretentiousness, drop the slang.

---

## E. Guidance for Phase 2

### Carry over
- First person, past tense.
- `should` as the spec voice when stating requirements or intended behaviour.
- Purpose clauses (`so that…`) for design rationale.
- Numbered enumeration inside prose sections; never bullet lists.
- Confident root-cause assertions (structure 6) — especially throughout §7.
- Short declarative closure before a transition (structure 3).
- Parenthetical qualification, rationed to ~1 per paragraph.
- British `-ise`.
- The term *overtuned*.
- Willingness to name what did not work, without softening it.

### Drop
- Lowercase `i`.
- `Also`-stacking of unrelated concerns — **one concern per paragraph** in the report.
- Comma splices.
- Chat hortatives: the report is retrospective, so *"let's do X"* becomes **"I decided to do X"**.
- Slang (`shtick`, `juice`, `strat`, `would be cool`).
- Direct address to a reader (`what do you think`) — convert those into stated open questions
  in §9.

### Net target register
**An engineer explaining a system to a competent peer who was not there** — confident,
specific, unshowy, and comfortable saying what failed.

### Quick self-check before submitting a section
1. Does any paragraph cover more than one concern? (the `Also` habit)
2. Any `there's` followed by a plural?
3. Any `less` where the noun is countable?
4. Any dropped article before a noun phrase starting a clause?
5. Any hortative left over from chat register?
6. Is every quantitative claim followed by its artifact?
