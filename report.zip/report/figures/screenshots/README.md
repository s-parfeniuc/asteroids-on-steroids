# Screenshot capture checklist

Seven slots referenced by the report. Capture at **1920×1080**, save as **PNG**, with the
**exact filenames** below — the `\includegraphics` calls in the section files expect them.

```bash
# Windowed at a known resolution (Linux/SDL build):
cd apps/Game.Sdl && ASTEROIDS_RES=1920x1080 dotnet run
```

**Debug keys:** `Z` profiler overlay · `X` dump profile to `profile.log` ·
`V`/`C`/`B` toggle particles / fills / streaks.

---

## Required

| # | Filename | Section | What must be visible | Notes |
|---|----------|---------|----------------------|-------|
| 1 | `gameplay-wide.png` | §6.1 | Player ship, several intact asteroids, vortex streaks, HUD | Establishing shot. Take it early in a wave when the field is still legible. |
| 2 | `fracture-midpropagation.png` | §5.4 | A crack **mid-flight** — partially cracked body, some cells detached, others still bonded | **The hardest and most important shot.** Use slow-mo (`R`) to hold the moment. May take several attempts. |
| 3 | `damaged-asteroid.png` | §5.1 | A heavily damaged body: hairline cracks along broken bonds, craters where cells were pulverised | Shows that concavity and damage share one representation. Zoom in if the camera allows. |
| 4 | `piercing.png` | §6.3 | A piercing round **inside** a body, having tunnelled rather than bounced | Fire `F` at a large asteroid. Slow-mo helps. |
| 5 | `profiler.png` | §7.2 | The `Z` overlay with the per-system breakdown and frame time legible | **Evidence, not decoration.** Text must be readable at print size — crop tightly to the overlay. |
| 6 | `winforms-windows.png` | §1.2, §3.4 | The game running as `AsteroidsGame.WinForms.exe` **on Windows**, with the window title bar visible | **Compliance evidence for the brief.** Must be the WinForms build on Windows, and the title bar is what proves it. Do not substitute the SDL build. |
| 7 | `editor.png` | §7.1, §8.6 | The shape/config editor with the live parameter sliders visible | Supports the "live tuning" verification claim. `cd tools/Editor && dotnet run` |

## Optional

| Filename | Section | Purpose |
|----------|---------|---------|
| `boss.png` | §6.4 | The mothership fight, if a good frame presents itself |
| `wave-banner.png` | §6.2 | A wave-transition banner, for the wave-system subsection |

---

## Guidance

- **Legibility beats spectacle.** These are figures in a technical report printed at
  ~15 cm wide. A busy frame full of particles reads as noise on paper. Prefer a moment
  where the *structure* is visible — cells, cracks, the bond geometry.
- **Crop to the subject.** A full 1920×1080 frame scaled to column width makes everything
  tiny. Crop shots 2, 3, 4 and 5 to the region that matters.
- **Turn off what distracts.** `V` disables particles — useful for shots 2 and 3, where
  dust obscures the fracture geometry that is the actual subject.
- **Take more than you need.** Shot 2 in particular is a timing problem; capture a burst
  and choose afterwards.
- Keep the originals here. If a shot is cropped, keep the uncropped version too
  (`*-original.png`), so the crop can be redone if the layout changes.
