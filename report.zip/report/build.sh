#!/usr/bin/env bash
# Build the report. Requires a TeX Live install with latexmk.
#   sudo apt install texlive-latex-recommended texlive-latex-extra \
#                    texlive-pictures texlive-science latexmk
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v latexmk >/dev/null 2>&1; then
  echo "error: latexmk not found. Install with:" >&2
  echo "  sudo apt install texlive-latex-recommended texlive-latex-extra texlive-pictures texlive-science latexmk" >&2
  exit 1
fi

latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
echo
echo "built: $(pwd)/main.pdf"
command -v pdfinfo >/dev/null 2>&1 && pdfinfo main.pdf | grep -E '^Pages'
